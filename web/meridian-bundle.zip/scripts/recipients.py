"""Load and validate the editor's saved recipient list (`recipients.txt`).

This is a tiny standalone module rather than living in `scripts.mail`
because reading a list of e-mail addresses isn't a mail-backend concern.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from scripts.text_utils import normalize_compatibility, strip_invisibles

log = logging.getLogger(__name__)


# Loose RFC 5322 -- enough to reject obvious typos plus header/separator
# injection (`;`, `,`, CR/LF) without overfitting on valid edge cases.
_EMAIL_RE = re.compile(r"^[^@\s;,<>]+@[^@\s;,<>]+\.[^@\s;,<>]+$")
# Hard ceiling -- a runaway recipients.txt cannot generate a 50 MB BCC.
_MAX_RECIPIENTS = 1000

# Invisible / bidi character handling delegates to `scripts.text_utils`
# so the recipients list, the subject-line builder, and the validator
# all defend against the same Word-paste hazards in lockstep.


def load_recipients(recipients_path: Path) -> list[str]:
    """Read a `recipients.txt` -- one address per line, # comments allowed.

    Each non-comment line is validated against a loose RFC 5322 pattern and
    rejected if it contains a separator character (`;`, `,`, CR/LF) that
    Outlook's BCC parser would split on -- prevents a malicious or typo'd
    line from expanding into multiple recipients. Result is deduplicated
    and capped at _MAX_RECIPIENTS entries.
    """
    if not recipients_path.exists():
        return []
    seen: set[str] = set()
    out: list[str] = []
    for raw in recipients_path.read_text(encoding="utf-8").splitlines():
        # NFKC FIRST so fullwidth ASCII variants get folded before the
        # regex sees them. Round-10 security MEDIUM: a crafted
        # `victim<U+FF20>evil.com` (FULLWIDTH COMMERCIAL AT) would
        # otherwise pass `_EMAIL_RE` because `[^@\s;,<>]` only excludes
        # ASCII `@` (U+0040). NFKC folds `<U+FF20>` -> `@`, after
        # which the regex sees the address it would have otherwise
        # missed. Same logic applies to fullwidth digits, periods, etc.
        # THEN strip invisibles so a hidden ZWSP / BOM / RLO doesn't
        # survive validation.
        line = strip_invisibles(
            normalize_compatibility(raw)
        ).strip().rstrip(",").strip()
        if not line or line.startswith("#"):
            continue
        if not _EMAIL_RE.match(line):
            log.warning(
                "Skipped one address from recipients.txt that didn't "
                "look right: %r (the rest are fine).", line)
            continue
        if line in seen:
            continue
        seen.add(line)
        out.append(line)
        if len(out) >= _MAX_RECIPIENTS:
            log.warning(
                "recipients.txt has more than %d entries -- truncated.",
                _MAX_RECIPIENTS)
            break
    return out


__all__ = ["load_recipients"]
