"""Public types shared by every mail backend."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

# `cid.py` imports only stdlib + scripts.html_utils, neither of which
# imports back into `base.py` -- no cycle, no need for TYPE_CHECKING.
from scripts.mail.cid import InlineImage


@dataclass(frozen=True)
class MailHandler:
    """Identifies the user's default email client."""

    kind: str        # "outlook" | "apple_mail" | "thunderbird" | "browser" | "other" | "unknown"
    name: str        # human-readable name from the OS
    raw_id: str = "" # OS-level identifier

    @property
    def is_outlook_desktop(self) -> bool:
        return self.kind == "outlook"


@dataclass(frozen=True)
class DraftEmail:
    """Pure-data description of an email draft to open in a client.

    All recipient/header fields are optional so a backend can ignore
    what it doesn't support (e.g. mailto: only honours `subject` + `bcc`,
    not `from_addr`). Adding fields here BEFORE more backends arrive
    avoids breaking-change refactors of every backend later.
    """

    html: str
    subject: str
    bcc: str | None = None
    cc: str | None = None
    to: str | None = None
    from_addr: str | None = None     # optional From: -- shared mailbox / department address
    reply_to: str | None = None
    attachments: tuple[Path, ...] = field(default_factory=tuple)
    # Inline-image attachment specs for the CID image-mode. Backends
    # that don't know how to inline-attach (clipboard_mailto) MUST
    # ignore this field; only `OutlookBackend` consumes it. The HTML
    # in `html` is already CID-rewritten when this is non-empty.
    #
    # NOTE: this is the only single-backend-specific field on
    # `DraftEmail`. If a SECOND single-backend field gets proposed,
    # refactor BEFORE adding it -- the right shape is a per-backend
    # extras dataclass nested under `DraftEmail`, not a growing list
    # of optional fields. See round-12 architect M5.
    inline_images: tuple[InlineImage, ...] = field(default_factory=tuple)
    preview_path: Path | None = None
    # Identifies the OS-detected default mail client (when known) so a
    # backend can use it for log messages without a back-channel call.
    handler: MailHandler | None = None


class MailBackend(Protocol):
    """Strategy for opening an email-draft window.

    Concrete backends live in `scripts/mail/<name>.py` and are added to
    `scripts.mail._BACKENDS` in priority order. The Protocol is
    structurally typed -- implementations don't `class Foo(MailBackend)`
    explicitly; they just expose `name`, `supports_inline_images`,
    `is_available`, `matches`, and `compose` with matching signatures.
    """

    name: str
    # Whether this backend can embed `DraftEmail.inline_images` as real
    # MIME parts (CID image-mode). Declared as a capability rather than
    # inferred from `name` at each call site: rounds 13-15 all spent
    # fixes on the same bug shape -- one code path deciding "is this
    # Outlook?" slightly differently from another, with the mismatch
    # surfacing only after the build and the GitHub push had already
    # run. A backend that answers this question about itself can't drift.
    supports_inline_images: bool

    def is_available(self) -> bool: ...

    def matches(self, handler: MailHandler) -> bool: ...

    def compose(self, draft: DraftEmail) -> None: ...


__all__ = ["MailHandler", "DraftEmail", "MailBackend"]
